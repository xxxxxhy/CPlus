^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package jackal_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.0 (2015-01-20)
------------------
* Add small hack to continue supporting the front_laser:=true arg, since that was prominently documented.
* Change from individual accessory args to a single "config" arg.
* Contributors: Mike Purvis

0.2.3 (2014-12-12)
------------------
* Added jackal_race world.
* Add hector_gazebo_plugins dependency.
* Contributors: Mike Purvis, spourmehr

0.2.2 (2014-09-10)
------------------
* Add author tags.
* Added launch arg to enable front-facing laser.
* Contributors: Mike Purvis

0.2.1 (2014-09-10)
------------------
* Install all directories.
* Contributors: Mike Purvis

0.2.0 (2014-09-09)
------------------
* Default world for Jackal sim is now a green one.
* Add missing dependencies on Gazebo plugin packages.
* Contributors: Mike Purvis

0.1.0 (2014-09-07)
------------------
* Initial version
* Contributors: Mike Purvis
